# ML-projects
here are some basic ml projects
This project is of basic calculator in python language.
It is built using the web application libraries of python like pywebio.
It takes inputs from user and prompts the user to select a radio button to perform operations like addition,subtraction,factorial,..so on and generates the corresponding output.


